# 国内行先別ページ
## ページ構成
- ホテル情報を紹介。その下に「対象ツアーはこちら」のような見せ方でツアーを並べる
  - イメージはデザインご確認下さい
- 商品情報
  - 各見出しで海外3商品（ 詳細は[スプレッド](https://docs.google.com/spreadsheets/d/1YS0j4Zp-pFX5CW1ILLcItaO9ZbWAKmpZCgOe6t5jaKc/edit#gid=1204548622)ご確認ください）
- 対象目的地は[行先別ページ](../dst.md)の海外枠をご確認ください。


![](../img/kokunai/dst.jpg)