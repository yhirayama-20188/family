# 国内TOP
## 依頼内容
- 各種テキスト（詳細は[スプレッド](https://docs.google.com/spreadsheets/d/1YS0j4Zp-pFX5CW1ILLcItaO9ZbWAKmpZCgOe6t5jaKc/edit#gid=1390508888)ご確認ください）
  1. キャッチフレーズ（30文字以内）
  2. 簡略説明文章（100文字以内）
  3. こだわりポイント（5つ、一行で最大25文字）
  4. 
- 対象目的地分が必要になります。（対象目的地は[行先別ページ](../dst.md)の国内枠をご確認ください。）


- デザイン
![](../img/kokunai/pc.png)